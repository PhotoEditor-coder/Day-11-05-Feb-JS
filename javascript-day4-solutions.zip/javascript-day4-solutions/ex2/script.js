const circle = document.querySelector("#circle");
const circleText = document.querySelector("#circle-text");

circle.addEventListener("mouseover", () => {
  circleText.innerHTML = "you are in the circle";
});

circle.addEventListener("mouseleave", () => {
  circleText.innerHTML = "you are outside of the circle";
});

circle.addEventListener("click", () => {
  circle.style.backgroundColor = "grey";
});

circle.addEventListener("dblclick", () => {
  circle.style.backgroundColor = "blue";
});
