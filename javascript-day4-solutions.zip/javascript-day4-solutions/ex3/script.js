// Array of objects representing people
const people = [
  {
    name: "Alice",
    age: 25,
    city: "New York",
    image:
      "https://cdn.pixabay.com/photo/2019/10/23/08/03/woman-4570763_1280.jpg",
  },
  {
    name: "Bob",
    age: 30,
    city: "Los Angeles",
    image:
      "https://cdn.pixabay.com/photo/2017/11/02/14/26/man-2911330_1280.jpg",
  },
  {
    name: "Charlie",
    age: 35,
    city: "Chicago",
    image:
      "https://cdn.pixabay.com/photo/2016/03/27/19/12/man-1283748_1280.jpg",
  },
];

const result = document.getElementById("result");

people.forEach((person) => {
  result.innerHTML += `
        <div>
            <div class="card my-3">
                <img src="${person.image}" class="card-img-top" alt="${
    person.name
  }">
                <div class="card-body">
                    <h5 class="card-title">${person.name}</h5>
                    <p class="card-text">Age: ${person.age}</p>
                    <p class="card-text">City: ${person.city}</p>
                    ${
                      person.age > 30
                        ? '<p class="text-danger">This person is above 30 years old.</p>'
                        : ""
                    }
                </div>
            </div>
        </div>
    `;
});
