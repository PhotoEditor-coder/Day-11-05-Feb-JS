const weatherDiv = document.getElementById("weather");
const tempDisplay = document.querySelector(".temp");
const descriptionDisplay = document.querySelector(".description");
const weatherImage = document.getElementById("weatherImage");

function weather(minTemp, maxTemp) {
  let randomNum = Math.floor(Math.random() * (maxTemp - minTemp + 1) + minTemp);
  let description = "";
  let imgSrc = "";

  if (randomNum <= 0) {
    description = "The weather is freezing!";
    imgSrc = "https://cdn.pixabay.com/photo/2013/10/27/17/14/frozen-201495_1280.jpg";
  } else if (randomNum <= 15) {
    description = "The weather is cold.";
    imgSrc = "https://cdn.pixabay.com/photo/2023/12/06/08/53/winter-8433257_1280.jpg";
  } else if (randomNum <= 25) {
    description = "The weather is moderate.";
    imgSrc = "https://cdn.pixabay.com/photo/2023/12/12/19/08/moutains-8445767_1280.jpg";
  } else if (randomNum <= 32) {
    description = "The weather is warm.";
    imgSrc = "https://cdn.pixabay.com/photo/2018/05/15/23/02/snow-3404534_1280.jpg";
  } else {
    description = "The weather is hot!";
    imgSrc = "https://cdn.pixabay.com/photo/2018/08/29/22/52/sunflowers-3640938_1280.jpg";
  }

  // Update the DOM
  tempDisplay.textContent = `Temperature: ${randomNum}°C`;
  descriptionDisplay.textContent = description;
  weatherImage.src = imgSrc;
  weatherImage.alt = description;

  return randomNum;
}
weather(-20, 40);

