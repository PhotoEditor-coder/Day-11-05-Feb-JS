const out = document.getElementById("grade");

const students = ["john", "jane", "bob"];
const grades = [24, 73, 100];

let student = prompt(
  "(challenge ex.) Enter a name:\n(john, jane, bob)"
).toLowerCase();

if (students.indexOf(student) != -1) {
  let grade = grades[students.indexOf(student)];
  let color = "blue"; // default

  if (grade < 60) color = "red";
  else if (grade < 70) color = "yellow";
  else if (grade < 100) color = "green";

  out.innerHTML = `${student} has reached <span style='color: ${color};'>${
    grades[students.indexOf(student)]
  }</span> points in Math this season.`;
} else {
  out.innerHTML = "No such student found.";
}
